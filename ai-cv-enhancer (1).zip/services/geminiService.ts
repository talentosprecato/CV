import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

/**
 * Generates a prompt for the Gemini model to edit a CV.
 * @param cvText The original CV text.
 * @param jobTitle The target job title or industry.
 * @param position The target position.
 * @param language The target language ('en' or 'it').
 * @returns A formatted prompt string.
 */
const createPrompt = (cvText: string, jobTitle: string, position: string, language: 'en' | 'it'): string => {
  const languageName = language === 'it' ? 'Italian' : 'English';
  const languageInstruction = `VERY IMPORTANT: The entire output, including all headings and content, MUST be in ${languageName}.`;

  return `
    You are an expert career coach and professional resume writer with over 20 years of experience. Your task is to rewrite and enhance the following CV to make it more creative, professional, and perfectly tailored for the role of "${position}" in the "${jobTitle}" industry.

    ${languageInstruction}

    **Instructions:**
    1.  **Analyze and Understand:** Carefully read the original CV to understand the candidate's skills, experience, and accomplishments.
    2.  **Target the Role:** Rewrite the summary, experience, and skills sections to directly target the specified job and position. Use keywords and language common in the "${jobTitle}" industry.
    3.  **Use Action Verbs:** Start bullet points with strong, impactful action verbs.
    4.  **Quantify Achievements:** Wherever possible, add quantifiable results to demonstrate impact (e.g., "Increased sales by 15%," "Reduced processing time by 30%"). If the original CV lacks numbers, suggest where they could be added as placeholders like "[metric]%".
    5.  **Professional Summary:** Create a compelling professional summary (3-4 sentences) at the top that immediately grabs the recruiter's attention and highlights the candidate's key qualifications for the role.
    6.  **Enhance Creativity & Professionalism:** Rephrase sentences to sound more professional and confident. The tone should be aspirational and competent.
    7.  **Formatting:** Structure the output using Markdown for clarity. Use headings (e.g., \`## Professional Summary\`, \`## Experience\`, \`## Skills\`, \`## Education\`). Use bolding to highlight key achievements.
    8.  **Preserve Core Information:** Do not invent new experiences or skills. Base your edits entirely on the information provided in the original CV.

    **Original CV:**
    ---
    ${cvText}
    ---

    **Target Job/Industry:** ${jobTitle}
    **Target Position:** ${position}

    Please provide only the edited CV in Markdown format, written entirely in ${languageName}.
  `;
};

/**
 * Sends the CV and job details to the Gemini API for editing.
 * @param originalCV The original CV text.
 * @param jobTitle The target job title.
 * @param position The target position.
 * @param language The target language.
 * @returns The edited CV text as a string.
 */
export const editCVWithAI = async (originalCV: string, jobTitle: string, position: string, language: 'en' | 'it'): Promise<string> => {
  try {
    const prompt = createPrompt(originalCV, jobTitle, position, language);
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: prompt,
    });
    
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to get a response from the AI model.");
  }
};