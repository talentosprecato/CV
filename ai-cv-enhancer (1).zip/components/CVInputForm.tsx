import React, { useRef } from 'react';
import { UploadIcon, SparklesIcon } from './icons';

// Add this to inform TypeScript about global libraries from CDN
declare global {
  interface Window {
    mammoth: any;
    pdfjsLib: any;
  }
}

interface CVInputFormProps {
  originalCV: string;
  setOriginalCV: (cv: string) => void;
  jobTitle: string;
  setJobTitle: (title: string) => void;
  position: string;
  setPosition: (pos: string) => void;
  language: 'en' | 'it';
  setLanguage: (lang: 'en' | 'it') => void;
  onFileRead: (content: string) => void;
  onSubmit: () => void;
  isLoading: boolean;
}

export const CVInputForm: React.FC<CVInputFormProps> = ({
  originalCV,
  setOriginalCV,
  jobTitle,
  setJobTitle,
  position,
  setPosition,
  language,
  setLanguage,
  onFileRead,
  onSubmit,
  isLoading,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // To prevent re-uploading the same file from not triggering onChange
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }

    const reader = new FileReader();

    try {
      let textContent = '';
      const fileExtension = file.name.split('.').pop()?.toLowerCase();

      if (fileExtension === 'txt') {
        reader.readAsText(file);
        textContent = await new Promise<string>((resolve, reject) => {
          reader.onload = (e) => resolve(e.target?.result as string);
          reader.onerror = () => reject(new Error('Failed to read .txt file'));
        });
      } else if (fileExtension === 'docx') {
        reader.readAsArrayBuffer(file);
        textContent = await new Promise<string>((resolve, reject) => {
          reader.onload = async (e) => {
            if (!e.target?.result) return reject(new Error('Failed to read file buffer'));
            try {
              const result = await window.mammoth.extractRawText({ arrayBuffer: e.target.result });
              resolve(result.value);
            } catch (err) {
              reject(new Error('Failed to parse .docx file. It might be corrupted or in an unsupported format.'));
            }
          };
          reader.onerror = () => reject(new Error('Failed to read .docx file'));
        });
      } else if (fileExtension === 'pdf') {
        reader.readAsArrayBuffer(file);
        textContent = await new Promise<string>((resolve, reject) => {
          reader.onload = async (e) => {
            if (!e.target?.result) return reject(new Error('Failed to read file buffer'));
            try {
              const pdf = await window.pdfjsLib.getDocument(e.target.result).promise;
              const numPages = pdf.numPages;
              let fullText = '';
              for (let i = 1; i <= numPages; i++) {
                const page = await pdf.getPage(i);
                const textContent = await page.getTextContent();
                const pageText = textContent.items.map((item: any) => item.str).join(' ');
                fullText += pageText + '\n';
              }
              resolve(fullText);
            } catch (err) {
              reject(new Error('Failed to parse .pdf file. It might be password-protected or corrupted.'));
            }
          };
          reader.onerror = () => reject(new Error('Failed to read .pdf file'));
        });
      } else {
        alert('Unsupported file type. Please upload a .txt, .pdf, or .docx file.');
        return;
      }

      onFileRead(textContent);

    } catch (error) {
      console.error('Error processing file:', error);
      alert((error as Error).message || 'An error occurred while processing the file.');
    }
  };
  
  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="p-6 bg-white rounded-xl shadow-lg border border-gray-200 space-y-6">
      <div>
        <h2 className="text-xl font-bold text-gray-700">1. Your Current CV</h2>
        <p className="text-sm text-gray-500">Paste your CV below or upload a .txt, .pdf, or .docx file.</p>
        <div className="mt-2 relative">
            <textarea
              className="w-full h-48 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition duration-150 ease-in-out disabled:bg-gray-100"
              placeholder="Paste your CV content here..."
              value={originalCV}
              onChange={(e) => setOriginalCV(e.target.value)}
              disabled={isLoading}
            />
            <button
                type="button"
                onClick={handleUploadClick}
                disabled={isLoading}
                className="absolute bottom-3 right-3 flex items-center gap-2 px-3 py-1.5 bg-gray-100 text-gray-600 rounded-md hover:bg-gray-200 disabled:opacity-50 text-sm"
            >
                <UploadIcon className="w-4 h-4" />
                Upload File
            </button>
            <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                accept=".txt,.pdf,.docx"
                onChange={handleFileChange}
                disabled={isLoading}
            />
        </div>
      </div>

      <div>
        <h2 className="text-xl font-bold text-gray-700">2. Your Target Role</h2>
        <p className="text-sm text-gray-500">Tell the AI what you're aiming for.</p>
        <div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="jobTitle" className="block text-sm font-medium text-gray-700 mb-1">
              Job / Industry
            </label>
            <input
              id="jobTitle"
              type="text"
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition duration-150 ease-in-out disabled:bg-gray-100"
              placeholder="e.g., Software Engineering"
              value={jobTitle}
              onChange={(e) => setJobTitle(e.target.value)}
              disabled={isLoading}
            />
          </div>
          <div>
            <label htmlFor="position" className="block text-sm font-medium text-gray-700 mb-1">
              Position
            </label>
            <input
              id="position"
              type="text"
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition duration-150 ease-in-out disabled:bg-gray-100"
              placeholder="e.g., Senior Frontend Developer"
              value={position}
              onChange={(e) => setPosition(e.target.value)}
              disabled={isLoading}
            />
          </div>
        </div>
      </div>
      
      <div>
        <h2 className="text-xl font-bold text-gray-700">3. Output Language</h2>
        <p className="text-sm text-gray-500">Choose the language for your enhanced CV.</p>
        <div className="mt-2">
          <div className="flex rounded-lg p-1 bg-gray-100">
            <button
              onClick={() => setLanguage('en')}
              disabled={isLoading}
              className={`w-full py-2 text-sm font-medium rounded-md transition-colors duration-200 ${
                language === 'en' ? 'bg-white text-primary-600 shadow' : 'text-gray-600 hover:bg-gray-200'
              }`}
            >
              English
            </button>
            <button
              onClick={() => setLanguage('it')}
              disabled={isLoading}
              className={`w-full py-2 text-sm font-medium rounded-md transition-colors duration-200 ${
                language === 'it' ? 'bg-white text-primary-600 shadow' : 'text-gray-600 hover:bg-gray-200'
              }`}
            >
              Italiano
            </button>
          </div>
        </div>
      </div>

      <div className="pt-2">
        <button
          onClick={onSubmit}
          disabled={isLoading || !originalCV || !jobTitle || !position}
          className="w-full flex items-center justify-center gap-2 bg-primary-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:bg-primary-300 disabled:cursor-not-allowed transition-colors duration-200"
        >
          <SparklesIcon className="w-5 h-5"/>
          {isLoading ? 'Enhancing...' : 'Enhance My CV'}
        </button>
      </div>
    </div>
  );
};