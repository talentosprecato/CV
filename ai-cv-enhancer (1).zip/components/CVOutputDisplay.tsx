import React, { useState, useRef } from 'react';
import { CopyIcon, CheckIcon, DownloadIcon } from './icons';

// Add this at the top to inform TypeScript about global libraries from CDN
declare global {
  interface Window {
    jspdf: any;
    html2canvas: any;
    htmlToDocx: any;
  }
}

interface CVOutputDisplayProps {
  originalCV: string;
  editedCV: string;
}

const MarkdownRenderer: React.FC<{ markdown: string }> = ({ markdown }) => {
    return (
        <>
            {markdown.split('\n\n').map((paragraph, pIndex) => {
                paragraph = paragraph.trim();
                if (paragraph.startsWith('## ')) {
                    return <h2 key={pIndex} className="text-xl font-bold mt-4 mb-2 text-gray-800">{paragraph.substring(3)}</h2>;
                }
                if (paragraph.startsWith('### ')) {
                    return <h3 key={pIndex} className="text-lg font-semibold mt-3 mb-1 text-gray-700">{paragraph.substring(4)}</h3>;
                }
                if (paragraph.startsWith('* ')) {
                    const listItems = paragraph.split('\n').map((item, lIndex) => {
                        const parts = item.substring(2).split('**');
                        return (
                            <li key={`${pIndex}-${lIndex}`}>
                                {parts.map((part, i) => i % 2 === 1 ? <strong key={i}>{part}</strong> : part)}
                            </li>
                        );
                    });
                    return <ul key={pIndex} className="list-disc pl-5 space-y-1">{listItems}</ul>;
                }
                 if(!paragraph) return null;
                // Regular paragraph
                const parts = paragraph.split('**');
                return (
                    <p key={pIndex}>
                        {parts.map((part, i) => i % 2 === 1 ? <strong key={i}>{part}</strong> : part)}
                    </p>
                );
            })}
        </>
    );
};


export const CVOutputDisplay: React.FC<CVOutputDisplayProps> = ({ originalCV, editedCV }) => {
  const [copied, setCopied] = useState(false);
  const [isDownloadingDocx, setIsDownloadingDocx] = useState(false);
  const [isDownloadingPdf, setIsDownloadingPdf] = useState(false);
  const cvContentRef = useRef<HTMLDivElement>(null);

  const handleCopy = () => {
    navigator.clipboard.writeText(editedCV).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };
  
  const handleDownloadDocx = async () => {
    setIsDownloadingDocx(true);
    if (!cvContentRef.current) {
        alert('Could not generate DOCX file. Content not found.');
        setIsDownloadingDocx(false);
        return;
    }

    try {
        const contentHtml = cvContentRef.current.innerHTML;
        const htmlString = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <style>
                    body { font-family: sans-serif; font-size: 11pt; }
                    h2 { font-size: 16pt; font-weight: bold; color: #2d3748; margin-top: 1.2em; margin-bottom: 0.6em; }
                    h3 { font-size: 13pt; font-weight: bold; color: #4a5568; margin-top: 1em; margin-bottom: 0.5em; }
                    p { margin-bottom: 0.5em; line-height: 1.5; }
                    strong { font-weight: bold; }
                    ul { margin-top: 0.5em; margin-bottom: 0.5em; padding-left: 20px; }
                    li { list-style-type: disc; margin-bottom: 0.25em; }
                </style>
            </head>
            <body>
                ${contentHtml}
            </body>
            </html>`;

        const fileBuffer = await window.htmlToDocx.asBlob(htmlString);
        const url = URL.createObjectURL(fileBuffer);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'enhanced-cv.docx';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    } catch (error) {
        console.error('Error generating DOCX:', error);
        alert('Failed to generate DOCX file.');
    } finally {
        setIsDownloadingDocx(false);
    }
  };

  const handleDownloadPdf = () => {
    setIsDownloadingPdf(true);
    if (!cvContentRef.current) {
      alert('Could not generate PDF file. Content not found.');
      setIsDownloadingPdf(false);
      return;
    }

    try {
      const { jsPDF } = window.jspdf;
      const pdf = new jsPDF({
        orientation: 'p',
        unit: 'mm',
        format: 'a4',
      });

      // Use the .html() method for higher fidelity. It intelligently handles pagination and scaling.
      pdf.html(cvContentRef.current, {
        callback: function (doc) {
          doc.save('enhanced-cv.pdf');
          // Set loading to false after the save dialog is triggered.
          setIsDownloadingPdf(false);
        },
        margin: [15, 15, 15, 15], // [top, right, bottom, left]
        autoPaging: 'text',       // Automatically handle page breaks.
        width: 180,               // Set content width (A4 is 210, so 210-15-15=180).
        windowWidth: cvContentRef.current.scrollWidth, // Use the content's actual width for better scaling.
      });
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Failed to generate PDF file.');
      setIsDownloadingPdf(false);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      {/* Original CV Column */}
      <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
        <h3 className="text-xl font-bold text-gray-700 mb-4">Original CV</h3>
        <div className="prose prose-sm max-w-none h-96 overflow-y-auto p-2 border rounded-md bg-gray-50">
          <pre className="whitespace-pre-wrap font-sans text-sm">{originalCV}</pre>
        </div>
      </div>

      {/* Edited CV Column */}
      <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
        <div className="flex flex-wrap justify-between items-center gap-4 mb-4">
          <h3 className="text-xl font-bold text-primary-700">AI-Enhanced CV</h3>
          <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={handleCopy}
                className="flex items-center gap-2 text-sm bg-primary-100 text-primary-700 font-medium py-1.5 px-3 rounded-lg hover:bg-primary-200 transition-colors"
              >
                {copied ? <CheckIcon className="w-4 h-4 text-green-500" /> : <CopyIcon className="w-4 h-4" />}
                {copied ? 'Copied!' : 'Copy'}
              </button>
              <button onClick={handleDownloadDocx} disabled={isDownloadingDocx || isDownloadingPdf} className="flex items-center gap-2 text-sm bg-gray-100 text-gray-700 font-medium py-1.5 px-3 rounded-lg hover:bg-gray-200 transition-colors disabled:opacity-50">
                  <DownloadIcon className="w-4 h-4" />
                  {isDownloadingDocx ? 'Saving...' : 'DOCX'}
              </button>
              <button onClick={handleDownloadPdf} disabled={isDownloadingDocx || isDownloadingPdf} className="flex items-center gap-2 text-sm bg-gray-100 text-gray-700 font-medium py-1.5 px-3 rounded-lg hover:bg-gray-200 transition-colors disabled:opacity-50">
                  <DownloadIcon className="w-4 h-4" />
                  {isDownloadingPdf ? 'Saving...' : 'PDF'}
              </button>
          </div>
        </div>
        <div ref={cvContentRef} className="prose prose-sm max-w-none h-96 overflow-y-auto p-4 border rounded-md bg-primary-50">
           <MarkdownRenderer markdown={editedCV} />
        </div>
      </div>
    </div>
  );
};